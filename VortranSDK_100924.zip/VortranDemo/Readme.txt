Stradus SDK @ 2024
Property of Vortran Laser

Installation:
- Extract/copy the contents of this folder to your preferred location
- Use venv or local python interpreter.
- use pip to install "requirements.txt"
-- to do this enter a terminal and type "pip install requirements.txt" from the folder containing the requirements file.
-- alternatively, you can install these libraries manually.

Use:
- System will use the first laser found. If your intent is to use more than 1 laser, please edit the section containing
- for x in range (len(lasers)) where x is the laser you want to control.
- Note you will need access to the commands list to drive vortran lasers. The example command in this file is
- LE=1 which refers to "Laser Enable ON". To test, send "LE=0" and laser should turn off.
- Additional commands can be used as needed, simply following the function call "send_my_command"
-- Note the option for writeOnly. If using as true, the system will issue the command and not check for a reply.
-- if false, the system will poll the laser output stream until an acknowledgement is received.


